﻿using System;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace GuestInfoApp
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();

            textBox1.Text = "정보를 입력하시오";
            textBox1.ForeColor = Color.Black; // 기본 글자색 설정


            textBox1.GotFocus += textBox1_GotFocus;
            textBox1.Leave += textBox1_Leave;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox1_GotFocus(object sender, EventArgs e)
        {
            if (textBox1.Text == "정보를 입력하시오")
            {
                textBox1.Text = ""; // 기본 텍스트 삭제
                textBox1.ForeColor = Color.Black; // 글자색을 기본 색으로 설정
            }
        }
        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                textBox1.Text = "정보를 입력하시오";
                textBox1.ForeColor = Color.Gray; // 기본 글자색으로 변경
            }
        }


        private void textBoxResult_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnBranch1_Click_1(object sender, EventArgs e)
        {
            try
            {
                string selectedBranch = "1"; // 선택된 지점
                textBox2.Text = "선택된 지점: 1호점"; // 선택 지점 표시

                // 데이터 가져오기
                string data = textBox1.Text;

                // 손님 이름 추출
                string guestName = Regex.Match(data, @"^(.+)", RegexOptions.Multiline).Groups[1].Value;

                // 총 게스트 수 추출
                int totalGuests = int.Parse(Regex.Match(data, @"게스트 (\d+)명").Groups[1].Value);

                // 반려동물 여부와 수 추출
                bool hasPet = data.Contains("반려동물");
                int petCount = hasPet ? int.Parse(Regex.Match(data, @"반려동물 (\d+)마리").Groups[1].Value) : 0;

                // 전화번호 추출
                var phoneMatch = Regex.Match(data, @"전화번호:\s*(\+?\d{1,3}\s\d{2,4}-\d{3,4}-\d{4})");
                string phoneNumber = phoneMatch.Success ? phoneMatch.Groups[1].Value : "전화번호 정보가 없습니다.";

                // 체크인 날짜 추출
                string checkIn = Regex.Match(data, @"체크인\s*(\d{4}년 \d+월 \d+일)").Groups[1].Value;

                // 체크아웃 날짜 추출
                string checkOut = Regex.Match(data, @"체크아웃\s*(\d{4}년 \d+월 \d+일)").Groups[1].Value;

                // 동일한 날짜 문제 해결
                if (checkIn == checkOut)
                {
                    textBoxResult.Text = "체크인 날짜와 체크아웃 날짜가 동일합니다. 입력 데이터를 확인해주세요.";
                    return;
                }

                // 게스트가 결제한 금액 추출
                var guestPaymentMatch = Regex.Match(data, @"게스트가 결제한 금액\s*₩([\d,]+)");
                string guestPayment = guestPaymentMatch.Success ? guestPaymentMatch.Groups[1].Value : "결제 정보가 없습니다.";

                // 총 지불 금액 추출
                string totalPayment = Regex.Match(data, @"총 금액\(KRW\).*₩([\d,]+)").Groups[1].Value;
                if (string.IsNullOrEmpty(totalPayment))
                {
                    totalPayment = Regex.Match(data, @"₩([\d,]+)$").Groups[1].Value;
                }
                // 결과 출력 준비
                string result = $"--- 예약 정보 ---\n" +
                                $"손님 이름: {guestName}\n" +
                                $"전화번호: {phoneNumber}\n" +
                                $"총 인원 수: {totalGuests}\n" +
                                $"반려 동물 유무 여부: {(hasPet ? "있음" : "없음")}\n" +
                                $"반려 동물 수: {petCount}\n" +
                                $"체크인 날짜: {checkIn}\n" +
                                $"체크아웃 날짜: {checkOut}\n\n" +
                                $"게스트 결제 금액: ₩{guestPayment}\n" +
                                $"수수료 제외한 총 금액: ₩{totalPayment}\n\n" +
                                $"--- 선택된 지점 ---\n" +
                                $"선택된 지점: {selectedBranch}호점\n\n" +
                                $"--- 추가 정보 ---\n";

                // 추가 정보 처리
                result += totalGuests switch
                {
                    2 => "Q패드 1개",
                    3 => "Q패드 1개, SS패드 1개, SS매트 1개",
                    4 => "Q패드 1개, SS패드 2개, SS매트 2개",
                    _ => "인원에 맞는 정보가 없습니다."
                };

                // 결과 출력
                textBoxResult.Text = result;
            }
            catch (Exception ex)
            {
                // 오류 출력
                textBoxResult.Text = $"오류 발생: {ex.Message}";
            }
        }

        private void btnBranch2_Click_1(object sender, EventArgs e)
        {
            try
            {
                string selectedBranch = "2"; // 선택된 지점
                textBox2.Text = "선택된 지점: 2호점"; // 선택 지점 표시

                // 데이터 가져오기
                string data = textBox1.Text;

                // 손님 이름 추출
                string guestName = Regex.Match(data, @"^(.+)", RegexOptions.Multiline).Groups[1].Value;

                // 총 게스트 수 추출
                int totalGuests = int.Parse(Regex.Match(data, @"게스트 (\d+)명").Groups[1].Value);

                // 반려동물 여부와 수 추출
                bool hasPet = data.Contains("반려동물");
                int petCount = hasPet ? int.Parse(Regex.Match(data, @"반려동물 (\d+)마리").Groups[1].Value) : 0;

                // 전화번호 추출
                var phoneMatch = Regex.Match(data, @"전화번호:\s*(\+?\d{1,3}\s\d{2,4}-\d{3,4}-\d{4})");
                string phoneNumber = phoneMatch.Success ? phoneMatch.Groups[1].Value : "전화번호 정보가 없습니다.";

                // 체크인 날짜 추출
                string checkIn = Regex.Match(data, @"체크인\s*(\d{4}년 \d+월 \d+일)").Groups[1].Value;

                // 체크아웃 날짜 추출
                string checkOut = Regex.Match(data, @"체크아웃\s*(\d{4}년 \d+월 \d+일)").Groups[1].Value;

                // 동일한 날짜 문제 해결
                if (checkIn == checkOut)
                {
                    textBoxResult.Text = "체크인 날짜와 체크아웃 날짜가 동일합니다. 입력 데이터를 확인해주세요.";
                    return;
                }

                // 게스트가 결제한 금액 추출
                var guestPaymentMatch = Regex.Match(data, @"게스트가 결제한 금액\s*₩([\d,]+)");
                string guestPayment = guestPaymentMatch.Success ? guestPaymentMatch.Groups[1].Value : "결제 정보가 없습니다.";

                // 총 지불 금액 추출
                string totalPayment = Regex.Match(data, @"총 금액\(KRW\).*₩([\d,]+)").Groups[1].Value;
                if (string.IsNullOrEmpty(totalPayment))
                {
                    totalPayment = Regex.Match(data, @"₩([\d,]+)$").Groups[1].Value;
                }
                // 결과 출력 준비
                string result = $"--- 예약 정보 ---\n" +
                                $"손님 이름: {guestName}\n" +
                                $"전화번호: {phoneNumber}\n" +
                                $"총 인원 수: {totalGuests}\n" +
                                $"반려 동물 유무 여부: {(hasPet ? "있음" : "없음")}\n" +
                                $"반려 동물 수: {petCount}\n" +
                                $"체크인 날짜: {checkIn}\n" +
                                $"체크아웃 날짜: {checkOut}\n\n" +
                                $"게스트 결제 금액: ₩{guestPayment}\n" +
                                $"수수료 제외한 총 금액: ₩{totalPayment}\n\n" +
                                $"--- 선택된 지점 ---\n" +
                                $"선택된 지점: {selectedBranch}호점\n\n" +
                                $"--- 추가 정보 ---\n";

                // 추가 정보 처리
                result += totalGuests switch
                {
                    2 => "SS패드 2개",
                    3 => "Q패드 1개, SS패드 2개",
                    4 => "Q패드 1개, SS패드 2개",
                    5 => "Q패드 1개, SS패드 3개, SS매트 1개",
                    6 => "Q패드 1개, SS패드 4개, SS매트 2개",
                    _ => "인원에 맞는 정보가 없습니다."
                };

                // 결과 출력
                textBoxResult.Text = result;
            }
            catch (Exception ex)
            {
                // 오류 출력
                textBoxResult.Text = $"오류 발생: {ex.Message}";
            }
        }
    }
}
